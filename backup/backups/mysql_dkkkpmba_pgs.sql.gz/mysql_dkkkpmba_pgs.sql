# MySQL backup created by phpMySQLAutoBackup - Version: 1.6.3
# 
# http://www.dwalker.co.uk/phpmysqlautobackup/
#
# Database: dkkkpmba_pgs
# Domain name: 
# (c)2017 
#
# Backup START time: 14:20:02
# Backup END time: 14:20:02
# Backup Date: 17 Feb 2017
 
drop table if exists `phpmysqlautobackup`; 
CREATE TABLE `phpmysqlautobackup` (
  `id` int(11) NOT NULL,
  `version` varchar(6) DEFAULT NULL,
  `time_last_run` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
insert into `phpmysqlautobackup` (`id`, `version`, `time_last_run`) values ('1', '1.6.3', '1487341202');
 
drop table if exists `phpmysqlautobackup_log`; 
CREATE TABLE `phpmysqlautobackup_log` (
  `date` int(11) NOT NULL,
  `bytes` int(11) NOT NULL,
  `lines` int(11) NOT NULL,
  PRIMARY KEY (`date`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
insert into `phpmysqlautobackup_log` (`date`, `bytes`, `lines`) values ('1486822801', '8151', '35');
insert into `phpmysqlautobackup_log` (`date`, `bytes`, `lines`) values ('1486909202', '8151', '35');
insert into `phpmysqlautobackup_log` (`date`, `bytes`, `lines`) values ('1486995601', '8151', '35');
insert into `phpmysqlautobackup_log` (`date`, `bytes`, `lines`) values ('1487082002', '8151', '35');
insert into `phpmysqlautobackup_log` (`date`, `bytes`, `lines`) values ('1487168402', '8151', '35');
insert into `phpmysqlautobackup_log` (`date`, `bytes`, `lines`) values ('1487254801', '8151', '35');
 
drop table if exists `tbl_enquiry`; 
CREATE TABLE `tbl_enquiry` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text COLLATE utf8_unicode_ci NOT NULL,
  `email` text COLLATE utf8_unicode_ci NOT NULL,
  `contact` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `message` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
insert into `tbl_enquiry` (`id`, `name`, `email`, `contact`, `message`) values ('1', 'Amit Anil Bhalerao', 'amitbaramatimca@gmail.com', '8796154725', 'Hello');
insert into `tbl_enquiry` (`id`, `name`, `email`, `contact`, `message`) values ('2', 'Kasturi', 'kasturi.bhalerao@gmail.com', '9970446416', 'I Love You Amtya');
insert into `tbl_enquiry` (`id`, `name`, `email`, `contact`, `message`) values ('3', 'Amit Anil Bhalerao', 'amitbaramatimca@gmail.com', '8796154725', 'asasasas');
insert into `tbl_enquiry` (`id`, `name`, `email`, `contact`, `message`) values ('4', 'Amit Anil Bhalerao', 'amitbaramatimca@gmail.com', '8796154725', 'Phadtare Global School');
 
drop table if exists `tbl_faculty`; 
CREATE TABLE `tbl_faculty` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `type` varchar(15) NOT NULL,
  `name` varchar(100) NOT NULL,
  `designation` varchar(100) NOT NULL,
  `qualification` varchar(100) NOT NULL,
  `experience` int(2) NOT NULL,
  `photo` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;
insert into `tbl_faculty` (`id`, `type`, `name`, `designation`, `qualification`, `experience`, `photo`) values ('17', 'Teaching', 'Miss .Kavita Mullathara Karunakaran', 'Principal', 'B.Com, M.A B.Ed', '13', 'Miss .Kavita Mullathara Karunakaran.png');
insert into `tbl_faculty` (`id`, `type`, `name`, `designation`, `qualification`, `experience`, `photo`) values ('19', 'Teaching', 'Miss.Mulani Reshma Yasin', 'Asst.Teacher', 'M.A M.Ed', '6', 'Miss.Mulani Reshma Yasin.png');
insert into `tbl_faculty` (`id`, `type`, `name`, `designation`, `qualification`, `experience`, `photo`) values ('22', 'Teaching', 'Mrs.Adhav Vishaka Bhikaji', 'Asst.Teacher', 'D.T.Ed,B.A', '4', 'Mrs.Adhav Vishaka Bhikaji.png');
insert into `tbl_faculty` (`id`, `type`, `name`, `designation`, `qualification`, `experience`, `photo`) values ('23', 'Teaching', 'More Mahesh Shahaji', 'Asst.Teacher', 'HSC.ATD', '4', 'More Mahesh Shahaji.png');
insert into `tbl_faculty` (`id`, `type`, `name`, `designation`, `qualification`, `experience`, `photo`) values ('21', 'Teaching', 'Mrs,Giramkar Madhuri Purushottam', 'Asst.Teacher', 'B.Sc, B.Ed', '5', 'Mrs,Giramkar Madhuri Purushottam.png');
insert into `tbl_faculty` (`id`, `type`, `name`, `designation`, `qualification`, `experience`, `photo`) values ('24', 'Teaching', 'Mrs.Khandekar Anuradha Bhaskar', 'Asst.Teacher', 'D.T.Ed,M.A BEd', '3', 'Mrs.Khandekar Anuradha Bhaskar.png');
insert into `tbl_faculty` (`id`, `type`, `name`, `designation`, `qualification`, `experience`, `photo`) values ('26', 'Teaching', 'Miss Kumbhar Priyanka Tanaji', 'Asst.Teacher', 'M.A. B.Ed', '3', 'Miss Kumbhar Priyanka.png');
insert into `tbl_faculty` (`id`, `type`, `name`, `designation`, `qualification`, `experience`, `photo`) values ('25', 'Teaching', 'Mrs.Chavan Nirmala Mahendra', 'Asst.Teacher', 'B.A D.Ed', '3', 'Mrs.Chavan Nirmala Mahendra.png');
insert into `tbl_faculty` (`id`, `type`, `name`, `designation`, `qualification`, `experience`, `photo`) values ('11', 'Non-Teaching', 'Mrs. Shirke Usha Mohan', 'Ladies Assistant', 'S.S.C.', '1', 'Mrs. Shirke Usha Mohan.jpg');
insert into `tbl_faculty` (`id`, `type`, `name`, `designation`, `qualification`, `experience`, `photo`) values ('12', 'Supporting', 'Mr. Jagdale Dattatray Kisan', 'Driver', 'S.S.C.', '1', 'Mr. Jagdale Dattatray Kisan.jpg');
insert into `tbl_faculty` (`id`, `type`, `name`, `designation`, `qualification`, `experience`, `photo`) values ('13', 'Supporting', 'Mr. Shaikh Munak Ahamad', 'Driver', 'S.S.C.', '1', 'Mr. Shaikh Munak Ahamad.jpg');
insert into `tbl_faculty` (`id`, `type`, `name`, `designation`, `qualification`, `experience`, `photo`) values ('20', 'Teaching', 'Miss.Dixit Dipali Shriniwas', 'Asst.Teacher', 'B.Sc.D.TEd', '4', 'Miss.Dixit Dipali Shriniwas.png');
insert into `tbl_faculty` (`id`, `type`, `name`, `designation`, `qualification`, `experience`, `photo`) values ('18', 'Teaching', 'Mrs.Kadam Vaishali Satyavijay', 'Asst.Teacher', 'M.A M.Ed', '9', 'Mrs.Kadam Vaishali Satyavijay.png');
 
drop table if exists `tbl_gallery`; 
CREATE TABLE `tbl_gallery` (
  `photoid` int(10) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `title` text NOT NULL,
  PRIMARY KEY (`photoid`)
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=latin1;
insert into `tbl_gallery` (`photoid`, `name`, `title`) values ('54', '_DSC0033 copy (FILEminimizer).jpg', 'School Event');
insert into `tbl_gallery` (`photoid`, `name`, `title`) values ('55', '3 (FILEminimizer).jpg', 'School Event');
insert into `tbl_gallery` (`photoid`, `name`, `title`) values ('56', '4 (FILEminimizer).jpg', 'School Event');
insert into `tbl_gallery` (`photoid`, `name`, `title`) values ('57', 'DSC_0155 (FILEminimizer).JPG', 'School Event');
insert into `tbl_gallery` (`photoid`, `name`, `title`) values ('58', 'DSC_0415 (FILEminimizer).JPG', 'School Event');
insert into `tbl_gallery` (`photoid`, `name`, `title`) values ('59', 'DSC_0428 (FILEminimizer).JPG', 'School Event');
insert into `tbl_gallery` (`photoid`, `name`, `title`) values ('60', 'DSC_0442 (FILEminimizer).JPG', 'School Event');
insert into `tbl_gallery` (`photoid`, `name`, `title`) values ('61', 'DSC_7611 (FILEminimizer).JPG', 'School Event');
insert into `tbl_gallery` (`photoid`, `name`, `title`) values ('62', 'IMG_0056 (FILEminimizer).JPG', 'School Event');
insert into `tbl_gallery` (`photoid`, `name`, `title`) values ('63', 'raj.3 (FILEminimizer).jpg', 'School Event');
 
drop table if exists `tbl_login`; 
CREATE TABLE `tbl_login` (
  `member_id` int(11) NOT NULL AUTO_INCREMENT,
  `UserName` varchar(200) NOT NULL,
  `Password` varchar(200) NOT NULL,
  `FirstName` varchar(200) NOT NULL,
  `LastName` varchar(200) NOT NULL,
  PRIMARY KEY (`member_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
insert into `tbl_login` (`member_id`, `UserName`, `Password`, `FirstName`, `LastName`) values ('1', 'pgsadmin', 'Phadtare12#$', 'Amit', 'Bhalerao');
 
drop table if exists `tbl_news`; 
CREATE TABLE `tbl_news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `newsdate` date NOT NULL,
  `subject` text NOT NULL,
  `description` text NOT NULL,
  `image` varchar(50) NOT NULL,
  `attachment` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
